$(document).ready(function() {
    $.ajax({
        url: "http://localhost:8080/loginbackend/getEmployee"
    }).then(function(employee) {
       $('.empId').append(employee.empId);
       $('.empname').append(employee.empname);
    });
});
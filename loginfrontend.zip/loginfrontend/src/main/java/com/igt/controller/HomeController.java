package com.igt.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	
	@RequestMapping("/")  
    public ModelAndView helloWorld() {  
        return new ModelAndView("index");  
    }  
	
	@RequestMapping("/rest")  
    public ModelAndView rest() {  
        return new ModelAndView("rest");  
    }
	
	
	@RequestMapping("/login")
    public ModelAndView login(
            @RequestParam(value="error", required = false)
            String error,
            @RequestParam(value="logout", required = false)
            String logout,
            Model model){

        if(error != null){
            model.addAttribute("error", "Invalid username and password");
        }

        if (logout !=null){
            model.addAttribute("msg", "You have been logged out successfully");
        }

        return new ModelAndView("login");
    }

	
}

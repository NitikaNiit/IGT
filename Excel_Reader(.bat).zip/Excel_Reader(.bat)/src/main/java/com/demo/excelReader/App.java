package com.demo.excelReader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

public class App {
	public static void main(String[] args) throws IOException, InvalidFormatException {
	/*	String path = "D:" + File.separator + "Timesheet" + File.separator + "Timesheet_Consolidated.xlsx";
		File file = new File(path);	
		List<FileInputStream> list = new ArrayList<FileInputStream>();
		list.add(new FileInputStream("D:/Timesheet/ABC.xlsx"));
		list.add(new FileInputStream("D:/Timesheet/DEF.xlsx"));
		ExcelReader.mergeExcelFiles(file, list);*/
		
		
		String path = "D:" + File.separator + "Timesheet_April" + File.separator + "Timesheet_Consolidated.xlsx";
		File file = new File(path);	
		file.getParentFile().mkdir();
		File f = new File("D:/TimeSheet");
		List<File> list = new ArrayList<File>(Arrays.asList(f.listFiles()));
		ExcelReader.mergeExcelFiles(file, list);
	}
	
	
}

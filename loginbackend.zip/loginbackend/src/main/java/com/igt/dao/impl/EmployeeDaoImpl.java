package com.igt.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.igt.dao.EmployeeDao;
import com.igt.model.Employee;

@Repository("empDaoImpl")
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	SessionFactory sessionFactory;

	public EmployeeDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		System.out.println("Constructor of Employee");
	}

	@Transactional
	public void registerEmployee(Employee employee) {
		/*Session session = sessionFactory.openSession();
		session.saveOrUpdate(employee);
		session.close();*/
		sessionFactory.openSession().saveOrUpdate(employee); 
	}

	public List<Employee> getAllEmployees() {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Employee");
		List<Employee> emp = query.list();
		session.close();
		return emp;

	}

	public Employee getEmployee(int empId) {
		Session session = sessionFactory.openSession();
		Employee employee = (Employee) session.get(Employee.class, empId);
		session.close();
		return employee;
	}

	@Transactional
	public void deleteEmployee(int empID) {
		Employee employee = (Employee) sessionFactory.getCurrentSession().get(Employee.class, empID);
		sessionFactory.getCurrentSession().delete(employee);

	}

	

}

package com.igt.dao;

import java.util.List;

import com.igt.model.Employee;

public interface EmployeeDao {
	
	public void registerEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();
	
	public void deleteEmployee(int empID);
	
	public Employee getEmployee(int empId);
	

}

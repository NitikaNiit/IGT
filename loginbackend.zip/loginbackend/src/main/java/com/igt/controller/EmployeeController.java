package com.igt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igt.dao.EmployeeDao;
import com.igt.model.Employee;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeDao empDao;

	@RequestMapping(value = "/getEmployee", method = RequestMethod.GET)
	public ResponseEntity<List<Employee>> getEmployees() {
		List<Employee> listEmployee = empDao.getAllEmployees();
		return new ResponseEntity<List<Employee>>(listEmployee, HttpStatus.OK);
	}

	@RequestMapping(value = "/registerEmployee", method = RequestMethod.PUT)
	public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
		empDao.registerEmployee(employee);
		return new ResponseEntity<String>("Successfully Registered", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deleteEmployee/{empId}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteEmployee(@PathVariable("empId") int empId) {
		empDao.deleteEmployee(empId);
		return new ResponseEntity<String>("Deleted User Succesfully", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/updateEmployee/{empId}", method = RequestMethod.PUT)
	public ResponseEntity<Employee> updateEmployee(@PathVariable("empId") int empId, @RequestBody Employee employee) {

		Employee currentEmployee = empDao.getEmployee(empId);
		empDao.registerEmployee(currentEmployee);

		return new ResponseEntity<Employee>(currentEmployee, HttpStatus.OK);
	}
	

}

/*package com.igt;

import java.util.Date;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.igt.dao.EmployeeDao;

import com.igt.model.Employee;

public class EmployeeDaoTest {

	public static void main(String args[]) 
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.igt");
		context.refresh();
		
		EmployeeDao employee=(EmployeeDao)context.getBean("employee");
		
		Employee emp=new Employee();
		emp.setCity("gurgram");
		emp.setDateofbirth(new Date());
		emp.setEmpemail("niti.khn@gmail.com");
		emp.setEmpId(100);
		emp.setEmpname("Nitika");
		emp.setGender("F");
		emp.setMobileno("9910783588");
		emp.setPassword("nitika");
		
		employee.registerEmployee(emp);
		
		System.out.println("Employee Details Added");
		
		
		//retrieve the blogs
		List<Blog> blogs = blogDAO.getAllBlogs();
		
		for(Blog b:blogs)
		{
			System.out.println(b.getBlogid()+ ":");
			System.out.println(b.getBlogName()+":");
			System.out.println(b.getBlogContent()+":");
			System.out.println(b.getUserid()+":");
			System.out.println(b.getLikes()+":");
			System.out.println(b.getStatus()+":");
			System.out.println(b.getCreateDate()+":");
		}
		
		//Deleting the blog
		blogDAO.deleteBlog(1001);
		System.out.println("Blog Deleted");
		
		//updating the blog
		
		Blog blog1 = blogDAO.getBlog(1001);
		blog1.setBlogname("Code");
		blogDAO.insertBlog(blog1);
		
		
		
	}

}*/
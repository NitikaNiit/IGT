package com.igt.iborders;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.net.SocketException;

public class LoginActivity extends AppCompatActivity {
    // User name
    private EditText et_Username;
    // Password
    private EditText et_Password;
    // Sign In
    private Button bt_SignIn;



    String URL = "http://57.253.242.201:88/securityws-V1/security-ws/SecurityServiceV1?WSDL";
    String NAMESPACE = "http://sita.aero/iborders/aras/SecurityServiceWSDLType/V1";
    String SOAP_ACTION = "";
    String METHOD_NAME = "AuthenticateAndGetUserDetailsRequest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Initialization
        et_Username = (EditText) findViewById(R.id.et_Username);
        et_Password = (EditText) findViewById(R.id.et_Password);
        bt_SignIn = (Button) findViewById(R.id.bt_SignIn);

        bt_SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LoginTask().execute();
            }
        });
    }
    private class LoginTask extends AsyncTask<Void, Void, Void> {

        private final ProgressDialog dialog = new ProgressDialog(
                LoginActivity.this);

        protected void onPreExecute() {

            this.dialog.setMessage("Logging in...");
            this.dialog.show();

        }

        protected Void doInBackground(final Void... unused) {
            String email = et_Username.getText().toString();
            String password = et_Password.getText().toString();
            boolean auth = doLogin(email, password);
            System.out.println(auth);

            return null;// don't interact with the ui!
        }

        private boolean doLogin(String user_id, String password) {

            boolean result = false;

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

            request.addProperty("UserId", user_id);
            request.addProperty("Password", password);
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(request);

            System.out.println(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);


            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                System.out.println("response" + response);

                if (response.toString().equalsIgnoreCase("success")) {
                    result = true;

                }

            } catch (SocketException ex) {
                Log.e("Error : ", "Error on soapPrimitiveData() " + ex.getMessage());
                ex.printStackTrace();
            } catch (Exception e) {
                Log.e("Error : ", "Error on soapPrimitiveData() " + e.getMessage());
                e.printStackTrace();
            }
            return result;

        }

    }}



package com.demo.excelReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class App {
	public static void main(String[] args) throws IOException {
		ExcelReader excel = new ExcelReader();
		String path = "D:" + File.separator + "Timesheet_April" + File.separator + "Timesheet_Consolidated.xlsx";
		File file = new File(path);
		file.getParentFile().mkdirs(); 
		file.createNewFile();
		
		List<FileInputStream> list = new ArrayList<FileInputStream>();
		list.add(new FileInputStream("D:/Timesheet/Timesheet_Kapil.xlsx"));
		list.add(new FileInputStream("D:/Timesheet/Timesheet_Sumit.xlsx"));
		
		excel.mergeExcelFiles(file, list);

	}
}
